/**
 * TODO - your comments here
 */

import java.util.*;

public class MyLinkedList<T> extends AbstractList<T>  {

    protected class Node {
        T data;
        Node next;
        Node prev;

        // TODO - your code here
    }

    protected class MyListIterator implements ListIterator<T> {

        // TODO - your code here

    }


    // TODO - your code here

}

