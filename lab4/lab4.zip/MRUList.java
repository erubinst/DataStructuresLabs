/**
 * TODO - your description here
 *
 * @author TODO YOUR NAME HERE
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class MRUList<T> extends MyLinkedList<T> {

    public boolean contains(Object o) {
        // TODO - your code here
	return false;
    }
    
    public boolean add(T x) {
        // TODO - your code here
	return false;
    }

    public void add(int index, T x) {
        // TODO - your code here
    }
    
}
